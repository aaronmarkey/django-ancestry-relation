from django.apps import AppConfig


class DjangoAncestryRelationConfig(AppConfig):
    name = 'django_ancestry_relation'
